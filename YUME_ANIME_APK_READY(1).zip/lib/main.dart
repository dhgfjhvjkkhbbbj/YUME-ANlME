
import 'package:flutter/material.dart';

void main() => runApp(const YumeApp());

const gold = Color(0xFFD4AF37);
const purple = Color(0xFF8B5CF6);
const bg = Color(0xFF080808);

class Anime {
  final String title;
  final String subtitle;
  final String image;
  final double rating;
  final int episodes;

  const Anime(this.title, this.subtitle, this.image, this.rating, this.episodes);
}

const animeList = [
  Anime('Attack on Titan', 'أكشن • دراما', 'https://picsum.photos/seed/aot/600/800', 9.6, 25),
  Anime('Jujutsu Kaisen', 'أكشن • خارق للطبيعة', 'https://picsum.photos/seed/jjk/600/800', 9.1, 24),
  Anime('Solo Leveling', 'أكشن • فانتازيا', 'https://picsum.photos/seed/solo/600/800', 9.3, 25),
  Anime('One Piece', 'مغامرة • أكشن', 'https://picsum.photos/seed/onepiece/600/800', 9.0, 1000),
];

class YumeApp extends StatefulWidget {
  const YumeApp({super.key});
  @override
  State<YumeApp> createState() => _YumeAppState();
}

class _YumeAppState extends State<YumeApp> {
  int tab = 0;
  String userName = 'أوتوساكا';
  final Set<String> favorites = {};

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'YUME ANIME',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: bg,
        colorScheme: ColorScheme.fromSeed(seedColor: gold, brightness: Brightness.dark),
        fontFamily: 'sans',
      ),
      home: Scaffold(
        body: SafeArea(
          child: IndexedStack(
            index: tab,
            children: [
              HomePage(
                userName: userName,
                favorites: favorites,
                onFavorite: (title) => setState(() {
                  favorites.contains(title) ? favorites.remove(title) : favorites.add(title);
                }),
                onOpen: (a) => Navigator.push(context, MaterialPageRoute(
                  builder: (_) => AnimeDetails(anime: a, isFavorite: favorites.contains(a.title),
                    onFavorite: () => setState(() {
                      favorites.contains(a.title) ? favorites.remove(a.title) : favorites.add(a.title);
                    })),
                )),
              ),
              SearchPage(
                onOpen: (a) => Navigator.push(context, MaterialPageRoute(
                  builder: (_) => AnimeDetails(anime: a, isFavorite: favorites.contains(a.title),
                    onFavorite: () => setState(() {
                      favorites.contains(a.title) ? favorites.remove(a.title) : favorites.add(a.title);
                    })),
                )),
              ),
              FavoritesPage(
                favorites: animeList.where((a) => favorites.contains(a.title)).toList(),
                onOpen: (a) => Navigator.push(context, MaterialPageRoute(
                  builder: (_) => AnimeDetails(anime: a, isFavorite: true,
                    onFavorite: () => setState(() => favorites.remove(a.title))),
                )),
              ),
              DownloadsPage(),
              SettingsPage(
                userName: userName,
                onNameChanged: (v) => setState(() => userName = v),
              ),
            ],
          ),
        ),
        bottomNavigationBar: NavigationBar(
          backgroundColor: const Color(0xFF0D0D0D),
          indicatorColor: purple.withOpacity(.22),
          selectedIndex: tab,
          onDestinationSelected: (i) => setState(() => tab = i),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home, color: gold), label: 'الرئيسية'),
            NavigationDestination(icon: Icon(Icons.search), label: 'البحث'),
            NavigationDestination(icon: Icon(Icons.favorite_border), selectedIcon: Icon(Icons.favorite, color: gold), label: 'المفضلة'),
            NavigationDestination(icon: Icon(Icons.download_outlined), label: 'التنزيلات'),
            NavigationDestination(icon: Icon(Icons.settings_outlined), label: 'الإعدادات'),
          ],
        ),
      ),
    );
  }
}

class Brand extends StatelessWidget {
  const Brand({super.key});
  @override
  Widget build(BuildContext context) => Column(
    children: const [
      Text('YUME', style: TextStyle(color: gold, fontSize: 31, fontWeight: FontWeight.w800, letterSpacing: 5)),
      Text('A N I M E', style: TextStyle(color: Colors.white, fontSize: 11, letterSpacing: 5)),
    ],
  );
}

class HomePage extends StatelessWidget {
  final String userName;
  final Set<String> favorites;
  final void Function(String) onFavorite;
  final void Function(Anime) onOpen;
  const HomePage({super.key, required this.userName, required this.favorites, required this.onFavorite, required this.onOpen});

  @override
  Widget build(BuildContext context) {
    return CustomScrollView(
      slivers: [
        SliverAppBar(
          pinned: true, backgroundColor: bg,
          title: const Brand(), centerTitle: true,
          leading: const Icon(Icons.menu, color: gold),
          actions: const [Icon(Icons.notifications_none, color: gold), SizedBox(width: 14)],
        ),
        SliverToBoxAdapter(child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 4),
          child: _JinoCard(name: userName),
        )),
        SliverToBoxAdapter(child: Padding(
          padding: const EdgeInsets.all(16),
          child: _HeroCard(onTap: () => onOpen(animeList[0])),
        )),
        const SliverToBoxAdapter(child: SectionTitle('متابعة المشاهدة')),
        SliverToBoxAdapter(child: _ContinueCard(anime: animeList[0], onTap: () => onOpen(animeList[0]))),
        const SliverToBoxAdapter(child: SectionTitle('الأنميات الرائجة')),
        SliverToBoxAdapter(child: SizedBox(
          height: 265,
          child: ListView.separated(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            scrollDirection: Axis.horizontal,
            itemCount: animeList.length,
            separatorBuilder: (_, __) => const SizedBox(width: 12),
            itemBuilder: (_, i) => AnimeCard(anime: animeList[i], favorite: favorites.contains(animeList[i].title),
              onFavorite: () => onFavorite(animeList[i].title), onTap: () => onOpen(animeList[i])),
          ),
        )),
        const SliverToBoxAdapter(child: SectionTitle('الحلقات الجديدة')),
        SliverList.builder(
          itemCount: animeList.length,
          itemBuilder: (_, i) => EpisodeRow(anime: animeList[i], episode: i + 1, onTap: () => onOpen(animeList[i])),
        ),
        const SliverToBoxAdapter(child: SizedBox(height: 20)),
      ],
    );
  }
}

class _JinoCard extends StatelessWidget {
  final String name;
  const _JinoCard({required this.name});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(
      color: const Color(0xFF111111),
      borderRadius: BorderRadius.circular(18),
      border: Border.all(color: purple.withOpacity(.55)),
    ),
    child: Row(children: [
      Container(width: 58, height: 58, decoration: BoxDecoration(
        shape: BoxShape.circle, color: purple.withOpacity(.18),
        border: Border.all(color: purple),
      ), child: const Icon(Icons.auto_awesome, color: purple, size: 30)),
      const SizedBox(width: 12),
      Expanded(child: Text('مرحبًا يا $name 👋\nماذا تريد أن تشاهد اليوم؟',
        textAlign: TextAlign.right, style: const TextStyle(fontSize: 15, height: 1.5))),
      const Text('جينو', style: TextStyle(color: purple, fontWeight: FontWeight.bold)),
    ]),
  );
}

class _HeroCard extends StatelessWidget {
  final VoidCallback onTap;
  const _HeroCard({required this.onTap});
  @override
  Widget build(BuildContext context) => InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(22),
    child: Container(
      height: 235,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
          colors: [Color(0xFF25200F), Color(0xFF0B0B0B), Color(0xFF17102B)]),
        border: Border.all(color: gold.withOpacity(.55)),
      ),
      child: Stack(children: [
        Positioned(right: 20, top: 20, child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
          decoration: BoxDecoration(color: gold, borderRadius: BorderRadius.circular(8)),
          child: const Text('مميز اليوم', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
        )),
        const Positioned(left: 20, top: 45, child: Text('Attack on Titan',
          style: TextStyle(color: gold, fontSize: 25, fontWeight: FontWeight.bold))),
        const Positioned(left: 20, top: 82, child: Text('حلقة جديدة • 1080p',
          style: TextStyle(color: Colors.white70))),
        Positioned(left: 20, bottom: 22, child: FilledButton.icon(
          onPressed: onTap, icon: const Icon(Icons.play_arrow, color: Colors.black),
          label: const Text('شاهد الآن', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
          style: FilledButton.styleFrom(backgroundColor: gold),
        )),
      ]),
    ),
  );
}

class SectionTitle extends StatelessWidget {
  final String text;
  const SectionTitle(this.text, {super.key});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(16, 12, 16, 10),
    child: Row(children: [
      Container(width: 4, height: 22, color: gold),
      const SizedBox(width: 8),
      Text(text, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
    ]),
  );
}

class AnimeCard extends StatelessWidget {
  final Anime anime; final bool favorite; final VoidCallback onFavorite; final VoidCallback onTap;
  const AnimeCard({super.key, required this.anime, required this.favorite, required this.onFavorite, required this.onTap});
  @override
  Widget build(BuildContext context) => SizedBox(width: 155, child: InkWell(
    onTap: onTap, borderRadius: BorderRadius.circular(16),
    child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Expanded(child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          gradient: const LinearGradient(colors: [Color(0xFF3A2B0B), Color(0xFF17102B)]),
          border: Border.all(color: gold.withOpacity(.45)),
        ),
        child: Stack(children: [
          const Center(child: Icon(Icons.movie_creation_outlined, size: 50, color: gold)),
          Positioned(top: 8, right: 8, child: InkWell(onTap: onFavorite,
            child: Icon(favorite ? Icons.favorite : Icons.favorite_border, color: gold))),
          Positioned(bottom: 8, left: 8, child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 4),
            decoration: BoxDecoration(color: Colors.black87, borderRadius: BorderRadius.circular(7)),
            child: Text('${anime.episodes} حلقة', style: const TextStyle(fontSize: 11)),
          )),
        ]),
      )),
      const SizedBox(height: 7),
      Text(anime.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold)),
      Text('${anime.rating} ★', style: const TextStyle(color: gold, fontSize: 12)),
    ]),
  ));
}

class _ContinueCard extends StatelessWidget {
  final Anime anime; final VoidCallback onTap;
  const _ContinueCard({required this.anime, required this.onTap});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 16),
    child: ListTile(
      onTap: onTap,
      tileColor: const Color(0xFF111111),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15), side: BorderSide(color: gold.withOpacity(.35))),
      leading: const CircleAvatar(backgroundColor: Color(0xFF2A1C05), child: Icon(Icons.play_arrow, color: gold)),
      title: Text(anime.title),
      subtitle: const Text('الحلقة 07 • متبقي 40%'),
      trailing: const SizedBox(width: 55, child: LinearProgressIndicator(value: .6, color: gold, backgroundColor: Colors.white12)),
    ),
  );
}

class EpisodeRow extends StatelessWidget {
  final Anime anime; final int episode; final VoidCallback onTap;
  const EpisodeRow({super.key, required this.anime, required this.episode, required this.onTap});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
    child: ListTile(
      onTap: onTap, tileColor: const Color(0xFF101010),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      leading: Container(width: 54, height: 54, decoration: BoxDecoration(
        color: const Color(0xFF251B07), borderRadius: BorderRadius.circular(10)),
        child: const Icon(Icons.play_circle_outline, color: gold)),
      title: Text('${anime.title} — الحلقة ${episode.toString().padLeft(2, '0')}'),
      subtitle: const Text('منذ 3 ساعات • 1080p'),
      trailing: const Icon(Icons.download_outlined, color: gold),
    ),
  );
}

class SearchPage extends StatefulWidget {
  final void Function(Anime) onOpen;
  const SearchPage({super.key, required this.onOpen});
  @override State<SearchPage> createState() => _SearchPageState();
}
class _SearchPageState extends State<SearchPage> {
  String q = '';
  @override Widget build(BuildContext context) {
    final results = animeList.where((a) => a.title.toLowerCase().contains(q.toLowerCase())).toList();
    return CustomScrollView(slivers: [
      const SliverAppBar(pinned: true, title: Text('البحث'), backgroundColor: bg),
      SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.all(16), child: TextField(
        onChanged: (v) => setState(() => q = v),
        decoration: InputDecoration(
          hintText: 'ابحث عن أنمي...',
          prefixIcon: const Icon(Icons.search, color: gold),
          filled: true, fillColor: const Color(0xFF111111),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide(color: gold.withOpacity(.4))),
        ),
      ))),
      SliverList.builder(itemCount: results.length, itemBuilder: (_, i) => EpisodeRow(anime: results[i], episode: i+1, onTap: () => widget.onOpen(results[i]))),
    ]);
  }
}

class FavoritesPage extends StatelessWidget {
  final List<Anime> favorites; final void Function(Anime) onOpen;
  const FavoritesPage({super.key, required this.favorites, required this.onOpen});
  @override Widget build(BuildContext context) => CustomScrollView(slivers: [
    const SliverAppBar(pinned: true, title: Text('المفضلة'), backgroundColor: bg),
    if (favorites.isEmpty)
      const SliverFillRemaining(child: Center(child: Text('لا توجد أنميات في المفضلة بعد')))
    else
      SliverPadding(padding: const EdgeInsets.all(16), sliver: SliverGrid.builder(
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 14, crossAxisSpacing: 14, childAspectRatio: .65),
        itemCount: favorites.length,
        itemBuilder: (_, i) => AnimeCard(anime: favorites[i], favorite: true, onFavorite: () {}, onTap: () => onOpen(favorites[i])),
      )),
  ]);
}

class DownloadsPage extends StatelessWidget {
  const DownloadsPage({super.key});
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: const [
    SizedBox(height: 10), Center(child: Brand()), SizedBox(height: 35),
    Text('التنزيلات', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
    SizedBox(height: 15),
    ListTile(leading: Icon(Icons.download_done, color: gold), title: Text('Attack on Titan — الحلقة 05'), subtitle: Text('1080p • جاهز للمشاهدة')),
    ListTile(leading: Icon(Icons.download_done, color: gold), title: Text('Jujutsu Kaisen — الحلقة 16'), subtitle: Text('720p • جاهز للمشاهدة')),
  ]);
}

class SettingsPage extends StatelessWidget {
  final String userName; final ValueChanged<String> onNameChanged;
  const SettingsPage({super.key, required this.userName, required this.onNameChanged});
  @override Widget build(BuildContext context) => ListView(children: [
    const SizedBox(height: 22), const Center(child: Brand()), const SizedBox(height: 25),
    ListTile(leading: const Icon(Icons.person, color: gold), title: Text(userName), subtitle: const Text('الحساب')),
    const Divider(color: Colors.white12),
    const SectionTitle('إعدادات المشاهدة'),
    const ListTile(leading: Icon(Icons.hd, color: gold), title: Text('الجودة الافتراضية'), trailing: Text('1080p')),
    const ListTile(leading: Icon(Icons.closed_caption, color: gold), title: Text('الترجمة'), trailing: Text('العربية')),
    const ListTile(leading: Icon(Icons.play_circle_outline, color: gold), title: Text('التشغيل التلقائي'), trailing: Icon(Icons.toggle_on, color: gold)),
    const SectionTitle('شخصية جينو'),
    const ListTile(leading: Icon(Icons.smart_toy, color: purple), title: Text('تفعيل جينو'), trailing: Icon(Icons.toggle_on, color: purple)),
    const ListTile(leading: Icon(Icons.record_voice_over, color: purple), title: Text('الترحيب باسم المستخدم'), trailing: Icon(Icons.toggle_on, color: purple)),
    const SectionTitle('التطبيق'),
    const ListTile(leading: Icon(Icons.dark_mode, color: gold), title: Text('المظهر'), trailing: Text('داكن')),
    const ListTile(leading: Icon(Icons.notifications_none, color: gold), title: Text('الإشعارات')),
    const ListTile(leading: Icon(Icons.info_outline, color: gold), title: Text('حول YUME ANIME'), trailing: Text('1.0.0')),
  ]);
}

class AnimeDetails extends StatelessWidget {
  final Anime anime; final bool isFavorite; final VoidCallback onFavorite;
  const AnimeDetails({super.key, required this.anime, required this.isFavorite, required this.onFavorite});
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Brand(), centerTitle: true, backgroundColor: bg),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      Container(height: 260, decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        gradient: const LinearGradient(colors: [Color(0xFF3B2A08), Color(0xFF1B1030)]),
        border: Border.all(color: gold.withOpacity(.5)),
      ), child: const Center(child: Icon(Icons.movie_creation, color: gold, size: 90))),
      const SizedBox(height: 18),
      Row(children: [
        Expanded(child: Text(anime.title, style: const TextStyle(fontSize: 27, fontWeight: FontWeight.bold))),
        IconButton(onPressed: onFavorite, icon: Icon(isFavorite ? Icons.favorite : Icons.favorite_border, color: gold)),
      ]),
      Text(anime.subtitle, style: const TextStyle(color: Colors.white70)),
      const SizedBox(height: 10),
      Text('${anime.rating} ★   •   ${anime.episodes} حلقة', style: const TextStyle(color: gold)),
      const SizedBox(height: 18),
      const Text('القصة', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
      const SizedBox(height: 7),
      const Text('تجربة مشاهدة أنمي داخل YUME ANIME مع معلومات الحلقات والمواسم والجودة والترجمة. هذا نص تجريبي ويمكن ربطه لاحقًا بقاعدة البيانات.'),
      const SizedBox(height: 20),
      FilledButton.icon(
        style: FilledButton.styleFrom(backgroundColor: gold, foregroundColor: Colors.black, padding: const EdgeInsets.all(15)),
        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PlayerPage(anime: anime))),
        icon: const Icon(Icons.play_arrow), label: const Text('شاهد الحلقة الأولى'),
      ),
      const SizedBox(height: 18),
      const Text('الحلقات', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
      ...List.generate(anime.episodes > 12 ? 12 : anime.episodes, (i) => ListTile(
        title: Text('الحلقة ${(i+1).toString().padLeft(2, '0')}'),
        subtitle: const Text('1080p • العربية'),
        leading: CircleAvatar(backgroundColor: const Color(0xFF251B07), child: Text('${i+1}', style: const TextStyle(color: gold))),
        trailing: const Icon(Icons.play_arrow, color: gold),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PlayerPage(anime: anime, episode: i+1))),
      )),
    ]),
  );
}

class PlayerPage extends StatefulWidget {
  final Anime anime; final int episode;
  const PlayerPage({super.key, required this.anime, this.episode = 1});
  @override State<PlayerPage> createState() => _PlayerPageState();
}
class _PlayerPageState extends State<PlayerPage> {
  bool playing = false;
  String quality = '1080p';
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Brand(), centerTitle: true, backgroundColor: bg),
    body: ListView(padding: const EdgeInsets.all(12), children: [
      Container(height: 230, decoration: BoxDecoration(
        color: Colors.black, borderRadius: BorderRadius.circular(18), border: Border.all(color: gold.withOpacity(.55)),
      ), child: Stack(alignment: Alignment.center, children: [
        const Icon(Icons.movie, color: gold, size: 80),
        IconButton.filled(onPressed: () => setState(() => playing = !playing),
          iconSize: 42, icon: Icon(playing ? Icons.pause : Icons.play_arrow)),
        Positioned(bottom: 10, left: 12, right: 12, child: LinearProgressIndicator(value: .36, color: gold, backgroundColor: Colors.white12)),
      ])),
      const SizedBox(height: 14),
      Text('${widget.anime.title} — الحلقة ${widget.episode.toString().padLeft(2, '0')}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      Row(children: [
        Expanded(child: DropdownButtonFormField<String>(value: quality, decoration: const InputDecoration(labelText: 'الجودة'),
          items: ['1080p','720p','480p'].map((x) => DropdownMenuItem(value: x, child: Text(x))).toList(),
          onChanged: (v) => setState(() => quality = v!))),
        const SizedBox(width: 10),
        const Expanded(child: DropdownButtonFormField<String>(value: 'العربية', decoration: InputDecoration(labelText: 'الترجمة'),
          items: [DropdownMenuItem(value: 'العربية', child: Text('العربية')), DropdownMenuItem(value: 'English', child: Text('English'))],
          onChanged: null)),
      ]),
      const SizedBox(height: 18),
      const Text('قائمة الحلقات', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
      ...List.generate(widget.anime.episodes > 10 ? 10 : widget.anime.episodes, (i) => ListTile(
        title: Text('الحلقة ${i+1}'), trailing: const Icon(Icons.play_circle_outline, color: gold),
      )),
      const SizedBox(height: 15),
      Container(padding: const EdgeInsets.all(15), decoration: BoxDecoration(
        color: const Color(0xFF120D1D), borderRadius: BorderRadius.circular(16), border: Border.all(color: purple.withOpacity(.55))),
        child: const Text('جينو: أهلًا يا قائد 👋 استمتع بالمشاهدة!'),
      ),
    ]),
  );
}
