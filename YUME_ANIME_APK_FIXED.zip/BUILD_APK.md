# YUME ANIME — APK Ready

هذا المشروع مجهز ليكون نقطة بداية لبناء APK على Android.

## على الكمبيوتر
بعد تثبيت Flutter وAndroid Studio:
1. افتح مجلد المشروع.
2. نفذ `flutter pub get`
3. نفذ `flutter build apk --release`
4. ستجد APK داخل `build/app/outputs/flutter-apk/`.

## على الهاتف فقط
يمكن رفع هذا المشروع إلى خدمة بناء Flutter سحابية تدعم GitHub/ZIP، ثم اختيار Android APK.

## تنبيه
هذه نسخة MVP: المشغل تجريبي، ولا تحتوي على محتوى أنمي محمي بحقوق نشر. لإطلاق خدمة حقيقية يجب استخدام محتوى تملكه أو تملك ترخيصه.
